<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * VirusTotal Antivirus Sample Lib.
 *
 * @package    antivirus_virustotal
 * @copyright  2015 Kevin Harris.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class antivirus_virustotal_client_key_setting extends admin_setting_configtext {
    /**
     * Validate data.
     *
     * This will attempt a request with the service provider and fail in the event that there was an error resolving.
     *
     * @param string $data
     * @return mixed True on success, else error message.
     */
	 
    public function validate($data) {
		$result = parent::validate($data);
		if ($result !== true) {
            return $result;
        }
		
		$post = array('apikey' => $data,'resource'=>'99017f6eebbac24f351415dd410d522d');
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://www.virustotal.com/vtapi/v2/file/report');
		curl_setopt($ch, CURLOPT_POST,1);
		curl_setopt($ch, CURLOPT_VERBOSE, 1); // remove this if your not debugging
		curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate'); // please compress data
		curl_setopt($ch, CURLOPT_USERAGENT, "gzip, My php curl client");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER ,true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

		$result=curl_exec ($ch);
		$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		print("status = $status_code\n");
		if ($status_code == 200) { // OK
			return true;
		} else {  // Error occured
			return false;
		}
		curl_close ($ch);
	}
	
	
	
        $result = parent::validate($data);
        if ($result !== true) {
            return $result;
        }
        $runningmethod = get_config('antivirus_clamav', 'runningmethod');
        if ($runningmethod === 'unixsocket') {
            $socket = stream_socket_client('unix://' . $data, $errno, $errstr, ANTIVIRUS_CLAMAV_SOCKET_TIMEOUT);
            if (!$socket) {
                return get_string('errorcantopensocket', 'antivirus_clamav', "$errstr ($errno)");
            } else {
                // Send PING query to ClamAV socket to check its running state.
                fwrite($socket, "nPING\n");
                $response = stream_get_line($socket, 4);
                fclose($socket);
                if ($response !== 'PONG') {
                    return get_string('errorclamavnoresponse', 'antivirus_clamav');
                }
            }
        }
        return true;
    }
}
