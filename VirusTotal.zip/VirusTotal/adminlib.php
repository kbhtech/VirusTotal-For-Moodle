<?php
/*
[ CRAM NOTES ]
	antivirus_virustotal_client_scan_method_setting as admin_setting_configselect values "inductive" or "deductive" default deductive;
	antivirus_virustotal_client_feedback_verbose_setting as admin_setting_configselect values true or false default false;
	antivirus_virustotal_client_useragent_setting as admin_setting_configtext
	antivirus_virustotal_client_key_setting as admin_setting_configtext
	antivirus_virustotal_local_file_encoding_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_scan_file_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_scan_url_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_scan_ip_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_scan_domain_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_rescan_file_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_reports_file_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_reports_url_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_reports_ip_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_reports_domain_setting as admin_setting_configtext
	antivirus_virustotal_server_resources_comments_setting as admin_setting_configtext
	antivirus_virustotal_client_scan_method_options as values "inductive" and "deductive"
	antivirus_virustotal_client_feedback_verbose_options as values "true" and "false"
*/

/**
 * virustotal antivirus adminlib.
 *
 * @package    antivirus_virustotal
 * @copyright  2015 Ruslan Kabalin, Lancaster University.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Admin setting for running, adds verification.
 *
 * @package    antivirus_virustotal
 * @copyright  2015 Ruslan Kabalin, Lancaster University.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class antivirus_virustotal_client_scan_method_setting extends admin_setting_configselect {
    /**
     * Save a setting
     *
     * @param string $data
     * @return string empty or error string
     */
    public function write_setting($data) {
        $validated = $this->validate($data);
        if ($validated !== true) {
            return $validated;
        }
        return parent::write_setting($data);
    }

    /**
     * Validate data.
     *
     * This ensures that unix socket transport is supported by this system.
     *
     * @param string $data
     * @return mixed True on success, else error message.
     */
    public function validate($data) {
        if ($data === 'unixsocket') {
            $supportedtransports = stream_get_transports();
            if (!array_search('unix', $supportedtransports)) {
                return get_string('errornounixsocketssupported', 'antivirus_virustotal');
            }
        }
        return true;
    }
}
/**
 * Admin setting for running, adds verification.
 *
 * @package    antivirus_virustotal
 * @copyright  2015 Ruslan Kabalin, Lancaster University.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class antivirus_virustotal_client_feedback_verbose_setting extends admin_setting_configselect {
    /**
     * Save a setting
     *
     * @param string $data
     * @return string empty or error string
     */
    public function write_setting($data) {
        $validated = $this->validate($data);
        if ($validated !== true) {
            return $validated;
        }
        return parent::write_setting($data);
    }

    /**
     * Validate data.
     *
     * This ensures that unix socket transport is supported by this system.
     *
     * @param string $data
     * @return mixed True on success, else error message.
     */
    public function validate($data) {
        if ($data === 'unixsocket') {
            $supportedtransports = stream_get_transports();
            if (!array_search('unix', $supportedtransports)) {
                return get_string('errornounixsocketssupported', 'antivirus_virustotal');
            }
        }
        return true;
    }
}
/**
 * Admin setting for unix socket path, adds verification.
 *
 * @package    antivirus_virustotal
 * @copyright  2015 Ruslan Kabalin, Lancaster University.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class antivirus_virustotal_pathtounixsocket_setting extends admin_setting_configtext {
    /**
     * Validate data.
     *
     * This ensures that unix socket setting is correct and virustotal is running.
     *
     * @param string $data
     * @return mixed True on success, else error message.
     */
    public function validate($data) {
        $result = parent::validate($data);
        if ($result !== true) {
            return $result;
        }
        $runningmethod = get_config('antivirus_virustotal', 'runningmethod');
        if ($runningmethod === 'unixsocket') {
            $socket = stream_socket_client('unix://' . $data, $errno, $errstr, ANTIVIRUS_virustotal_SOCKET_TIMEOUT);
            if (!$socket) {
                return get_string('errorcantopensocket', 'antivirus_virustotal', "$errstr ($errno)");
            } else {
                // Send PING query to virustotal socket to check its running state.
                fwrite($socket, "nPING\n");
                $response = stream_get_line($socket, 4);
                fclose($socket);
                if ($response !== 'PONG') {
                    return get_string('errorvirustotalnoresponse', 'antivirus_virustotal');
                }
            }
        }
        return true;
    }
}
